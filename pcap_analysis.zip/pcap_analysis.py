# Install dpkt if necessary
# pip install dpkt

import dpkt
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

#------------------- PARSE PCAP FILE -------------------
# Create an empty list to store packet data
packet_data = []

# Open the pcap file for reading
with open("trace.pcap", "rb") as f:
    # Create a pcap reader object
    pcap_reader = dpkt.pcap.Reader(f)

    # Iterate over each packet in the pcap file
    for timestamp, buf in pcap_reader:
        # Parse the Ethernet frame
        eth = dpkt.ethernet.Ethernet(buf)

        # Extracting all available information from the packet
        packet_info = {
            "Timestamp": timestamp,
            "Ethernet Type": eth.type
        }

        # Check if the packet is IP
        if isinstance(eth.data, dpkt.ip.IP):
            ip = eth.data
            packet_info["IP Source"] = dpkt.utils.inet_to_str(ip.src)
            packet_info["IP Destination"] = dpkt.utils.inet_to_str(ip.dst)
            packet_info["IP Version"] = ip.v
            packet_info["IP Protocol"] = ip.p
            packet_info["IP TTL"] = ip.ttl
            packet_info["Length"] = len(buf)

            # Check if the packet is TCP
            if isinstance(ip.data, dpkt.tcp.TCP):
                packet_info["Source Port"] = ip.data.sport
                packet_info["Destination Port"] = ip.data.dport
                packet_info["Protocol"] = "TCP"
            # Check if the packet is UDP
            elif isinstance(ip.data, dpkt.udp.UDP):
                packet_info["Source Port"] = ip.data.sport
                packet_info["Destination Port"] = ip.data.dport
                packet_info["Protocol"] = "UDP"
            # Check if the packet is ICMP
            elif isinstance(ip.data, dpkt.icmp.ICMP):
                packet_info["Protocol"] = "ICMP"
            else:
                packet_info["Protocol"] = "Unknown"


        # Check if the packet is ARP
        elif isinstance(eth.data, dpkt.arp.ARP):
            packet_info["Length"] = len(buf)
            packet_info["Protocol"] = "ARP"
        else:
            packet_info["Protocol"] = "Unknown"
            packet_info["Length"] = len(buf)

        # Append packet data to the list
        packet_data.append(packet_info)

# Create a DataFrame from the list of packet data
df = pd.DataFrame(packet_data)

# Print the DataFrame
# print(df.head(5))

#------------------- CATEGORISE TRAFFIC BY PROTOCOL  -------------------

# Calculate the total traffic volume for each protocol category
total_tcp_volume = df[df['Protocol'] == 'TCP']['Length'].sum()
total_udp_volume = df[df['Protocol'] == 'UDP']['Length'].sum()
total_icmp_volume = df[df['Protocol'] == 'ICMP']['Length'].sum()
total_arp_volume = df[df['Protocol'] == 'ARP']['Length'].sum()
total_unknown_volume = df[df['Protocol'] == 'Unknown']['Length'].sum()

# Calculate the total traffic volume
total_traffic_volume = total_tcp_volume + total_udp_volume + total_icmp_volume + total_arp_volume + total_unknown_volume

# Calculate the percentages for each protocol category
tcp_percentage = (total_tcp_volume / total_traffic_volume) * 100
udp_percentage = (total_udp_volume / total_traffic_volume) * 100
icmp_percentage = (total_icmp_volume / total_traffic_volume) * 100
arp_percentage = (total_arp_volume / total_traffic_volume) * 100
unknown_percentage = (total_unknown_volume / total_traffic_volume) * 100

# Print the percentages
print("TCP Percentage: {:.4f}%".format(tcp_percentage))
print("UDP Percentage: {:.4f}%".format(udp_percentage))
print("ICMP Percentage: {:.4f}%".format(icmp_percentage))
print("ARP Percentage: {:.4f}%".format(arp_percentage))
print("Unknown Percentage: {:.4f}%".format(unknown_percentage))

# Create protocol_percentages for plotting
protocol_percentages = {
    'TCP': tcp_percentage,
    'UDP': udp_percentage,
    'ICMP': icmp_percentage,
    'ARP': arp_percentage,
    'Unknown': unknown_percentage
}

# Create lists for protocol names and percentages
protocols = list(protocol_percentages.keys())
percentages = list(protocol_percentages.values())

# Create a bar chart for each protocol
plt.figure(figsize=(10, 6))
plt.bar(protocols, percentages, color='blue')

# Set plot labels and title
plt.xlabel('Protocol')
plt.ylabel('Percentage of Traffic Volume')
plt.title('Percentage of Traffic Volume by Protocol')

# Show the plot
plt.grid(True)
plt.tight_layout()
plt.show()

# ------------------- CDF OF PACKET SIZE -------------------
# Sort the DataFrame by packet size
df_sorted = df.sort_values(by='Length')

# Calculate the cumulative distribution
cumulative_percentages = (df_sorted.reset_index().index + 1) / len(df_sorted) * 100

# Plot the CDF
plt.figure(figsize=(10, 6))
plt.plot(df_sorted['Length'], cumulative_percentages, marker='.', linestyle='none', markersize=2)
plt.xlabel('Packet Size (bytes)')
plt.ylabel('Cumulative Percentage (%)')
plt.title('CDF of Packet Size')
plt.grid(True)
plt.tight_layout()
plt.show()

# ------------------- CALCULATE FLOWS AND FLOW SIZES -------------------
# Group the DataFrame by the 5-tuple fields and sum the lengths of packets in each group
flow_sizes = df.groupby(['IP Source', 'IP Destination', 'Source Port', 'Destination Port', 'Protocol'])['Length'].sum()

# Reset the index to convert the groupby result to a DataFrame
flow_df = flow_sizes.reset_index()

# Rename the columns for clarity
flow_df.columns = ['IP Source', 'IP Destination', 'Source Port', 'Destination Port', 'Protocol', 'Flow Size']

# Print the DataFrame
print(flow_df.head(5))

# ------------------- CDF OF FLOW SIZES -------------------
# Sort the DataFrame by flow size
flow_df_sorted = flow_df.sort_values(by='Flow Size')

# Calculate the cumulative distribution
cumulative_percentages = (np.arange(len(flow_df_sorted)) + 1) / len(flow_df_sorted) * 100

# Plot the CDF with connected dots
plt.figure(figsize=(10, 6))
plt.plot(flow_df_sorted['Flow Size'], cumulative_percentages, marker='.', markersize=2)
plt.xlabel('Flow Size (bytes)')
plt.ylabel('Cumulative Percentage (%)')
plt.title('CDF of Flow Size')
plt.grid(True)
plt.tight_layout()
plt.show()

